var express = require('express');
const router = express.Router();
const connection = require('../Model/database');
connection.connect(function(err)
{
    if(err)
        console.log(err);
    else
        console.log('Connected with Database');
});

router.get('/',function(req,res)
{
    res.send("Welcome To server ");
});

router.get('/login2',function(req,res)
{
    res.render('login2');
});
router.post('/validate', function(req,res)
{
    var email=req.body.email;
    var pwd = req.body.pass;
    connection.query('SELECT * FROM register WHERE REMAIL LIKE ? AND RPASS LIKE ?',[email,pwd],function(err,result)
    {
        console.log("created");
        if(result)
        {
            console.log("Entered");
            connection.query('SELECT * FROM marksheet',function(err,result1)
            {
                console.log(result1.length);
                        res.render('marksheet',{data:result1});
            });
        }
    });
});

router.get('/signup',function(req,res)
{
    res.render('signup');
});

router.post('/check',function(req,res)
{
    var name = req.body.uname;
    var rollno=req.body.roll;
    var email = req.body.mail;
    var pwd = req.body.pass1;
    //var pass2 = req.body.pass2;
    var radio = req.body.radio;
    connection.query('INSERT INTO register VALUES(?,?,?,?,?)',[name,rollno,email,pwd,radio],function(err,result)
    {
        if(err)
            throw err;
        else
            console.log("Values inserted successfully");
    });
    res.render('login2');
});
module.exports = router;
