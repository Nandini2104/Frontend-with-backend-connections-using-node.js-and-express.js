const mysql = require('mysql2');
var conn = mysql.createConnection(
    {
        host:'127.0.0.1',
        user:'root',
        password:'NANDINI!@#',
        database:'student',
        port:3306
    }
);
module.exports=conn;
