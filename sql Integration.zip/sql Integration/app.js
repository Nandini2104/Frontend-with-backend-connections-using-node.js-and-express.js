var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var port=2104;

app.use(bodyParser.urlencoded({extended:false}));
app.use(express.static(__dirname));

app.set('views', './views');
app.set('view engine', 'ejs');

const myRoutes = require('./Controller/route');
app.use(myRoutes);

app.get('/signup',function(req,res){
    res.render('signup');
})

app.listen(port,()=>{
    console.log(`Server is running at the port ${port}`);
})