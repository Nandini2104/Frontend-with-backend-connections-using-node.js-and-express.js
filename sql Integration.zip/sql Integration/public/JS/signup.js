function matchPassword()
{
  var pw = document.getElementById("pswd1").value;  
  var pwd = document.getElementById("pswd2").value; 
  if(pw=="" || pwd=="")
      alert("password required");
  else if(pw!=pwd)
     alert("Password is not correct");
  else
    alert("Thanks for Signing up!!");  
}
function verifyForm()
  {  
    
    var pw = document.getElementById("pswd1").value;  
    //check empty password field  
    if(pw.length == 0)
    {  
        document.getElementById("pswd").innerHTML = "**Fill the password please!";  
        return false;  
    } 
    //minimum password length validation  
    else if(pw.length<=8 && pw.length>=12) 
    {  
        document.getElementById("pswd").innerHTML = "Password length must be atleast 8-12 characters";  
        return false;  
    }  
    else
    {
      document.getElementById("pswd").innerHTML="";
      return true;
    }
}  