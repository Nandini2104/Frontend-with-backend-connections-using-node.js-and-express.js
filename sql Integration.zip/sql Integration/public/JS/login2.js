function validate()
{
    var vemail = 0;
    var vpwd = 0;
    var pattern = "^[a-zA-Z0-9._-]+@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,6})+$";

    var email = document.form1.email.value;
    var pwd = document.form1.pass.value;
    if(email.length == 0)
    {
        document.getElementById("mail").innerHTML="Please enter email";
        return false;
    }
    else if(email.match(pattern))
    {
        document.getElementById("mail").innerHTML="";
        vemail=1;
    }
    else
    {
        document.getElementById("mail").innerHTML="Enter valid Email id";
        return false;
    }

    if(pwd.length == 0)
    {
        document.getElementById("pwd1").innerHTML="Please enter password";
        return false;
    }
    else if(pwd.length >= 8 && pwd.length <= 12)
    {
        document.getElementById("pwd1").innerHTML="";
        vpwd = 1;
    }
    else{
        document.getElementById("pwd1").innerHTML="Password length must be 8 to 12";
        return false;
    }
    if(vemail == 1 && vpwd == 1)
    {
        if(confirm("Are you sure ?"))
        {
            return true;
        }
    }
}